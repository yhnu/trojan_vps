# sample-hexo-blog

## Built With

* Node.js 12.16.0
* Hexo 3.1.0
* NexT 7.7.1

## Download

### Debian or Ubuntu

```
apt install wget zip unzip

wget https://github.com/lionlibr/sample-hexo-blog/archive/master.zip

unzip master.zip
```

### CentOS

```
yum install wget zip unzip

wget https://github.com/lionlibr/sample-hexo-blog/archive/master.zip

unzip master.zip
```

## Update NexT Theme

Requires Git to be installed first.

```
cd sample-hexo-blog-master

git submodule update
```

## Generate Public HTML

Requires Node.js and Hexo to be installed first.

```
cd sample-hexo-blog-master

hexo generate
```

## Copy Public HTML to Web Server

```
cd sample-hexo-blog-master
```

### Debian or Ubuntu

```
cp -rf public/* /var/www/html/
```

### CentOS

```
cp -rf public/* /usr/share/nginx/html/
```

